module.exports = {
    name: 'clear',
    execute(args, stream){
        stream.write('\x1b[2J\x1b[H')
    }
}