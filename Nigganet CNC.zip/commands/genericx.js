const { attack } = require(`../ws`)
const global = require(`../global`)

module.exports = {
    command: true,
    execute(args, stream, method){
        const ip = args[0]
        const port = args[1]
        const time = args[2]
        if(!time || !port || !ip) return stream.write(`Usage: .${method.name} ${method.args}\r\nExample: .${method.name} ${method.example}\r\n`)
        stream.write(global.cls)
        stream.write(`\x1b[38;5;1mTotal Ongoing: 39    Ongoing: 2    Expiry: 10395 Milleniums\x1b[0m\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`                       \x1b[38;5;9m╔═══════ Attack Information ═════╗\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mHost: ${ip}${' '.repeat(25 - ip.length < 0 ? 0 : 25 - ip.length)}\x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mPort: ${port}${' '.repeat(25 - port.length)}\x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mAttack Time: ${time}s${' '.repeat(17 - time.length)}\x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mMethod: ${method.name}${' '.repeat(23 - method.name.length)}\x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m╠═══════ User Information ═══════╣\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mUsername: root                 \x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mPlan: Admin                    \x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mPlan Expiry: 10395 Milleniums  \x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mUser Ongoing: 2                \x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m║ \x1b[0mTotal Ongoing: 39              \x1b[38;5;9m║\r\n`)
        stream.write(`                       \x1b[38;5;9m╚════════════════════════════════╝\x1b[0m\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        stream.write(`\r\n`)
        attack(time)
    }
}

          