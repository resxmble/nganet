const { parentPort } = require('worker_threads')
const config = require('./config/title.json')

function r(t){return Array.from({length:t},()=>String.fromCharCode(Math.floor(65536*Math.random()))).join("")}
let botsOnline = config.default_bot_count
async function updateTitle(){
    while(true){
        botsOnline += (Math.random()<0.5?-1:1)*(Math.floor(Math.random()*config.bot_change_treshold)+1)
        const title = `\x1b]0;NiggaNet v3 - ${botsOnline} Bots online\x07`
        parentPort.postMessage(title)
        const delay = Math.floor(Math.random()*(config.bot_change_delay.max - config.bot_change_delay.min)) + config.bot_change_delay.min
        await new Promise(resolve=>setTimeout(resolve, delay))
    }
}
updateTitle()
