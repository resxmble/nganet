module.exports = {
    prefix: '\x1b[48;5;088m root \x1b[48;5;124m </> \x1b[48;5;160m NiggaNet \x1b[0m ',
    cls: '\x1b[2J\x1b[H'
}