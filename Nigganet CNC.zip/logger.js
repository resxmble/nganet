const { createLogger, format, transports } = require('winston')
const { combine, timestamp, printf } = format

module.exports = createLogger({
    level: 'debug',
    format: combine(
        timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        printf(({ timestamp, level, message, label }) => `${timestamp} | ${level.toUpperCase().padEnd(8)} | default  -  ${message}`)
    ),
    transports: [new transports.Console()]
})