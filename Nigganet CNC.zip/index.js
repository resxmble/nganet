const fs = require('fs')
const { Server } = require('ssh2')
const path = require('path')
const commands = {}
const global = require('./global')
const { Worker } = require('worker_threads')
const methodConfig = require('./config/methods.json')
const methods = {}
const logger = require('./logger')

fs.readdirSync(path.join(__dirname, 'commands')).forEach(file => {
    const command = require(`./commands/${file}`)
    if(!command.name && !command.command) return
    if(!command.command) commands[command.name] = command.execute
    else commands[file.replaceAll('.js', '')] = command.execute
})

for(const method of methodConfig.methods){
    methods[method['name']] = method
}


const hostKey = fs.readFileSync('host.key')

new Server({ hostKeys: [hostKey] }, client => {
    logger.info(`Client Connected!`)
    client.on('error', err => logger.warning('Uncaught Error!!! ', err))
    client.on('authentication', ctx => {
        if (ctx.method === 'password' && ctx.username === 'root'/* && ctx.password === 'net'*/) ctx.accept()
        else ctx.reject(['password'], false)
    }).on('ready', () => {
        client.on('session', (accept, reject) => {
            const session = accept()
            //session.once('pty', (accept, reject) => accept())
            session.once('shell', (accept, reject) => {
                const stream = accept()
                stream.write(global.cls)
                const worker = new Worker('./title.js')
                worker.on('message', (title) => { stream.write(title) })
                stream.write(global.prefix)
                stream.on('data', data => {
                    if(data.toString().trim() === '') return
                    let [cmd, ...args] = data.toString().trim().split(' ')
                    if(cmd.startsWith('.')) cmd = cmd.slice(1)
                    if(methods[cmd]) commands[methods[cmd].file](args, stream, methods[cmd])
                    else if(commands[cmd]) {commands[cmd](args, stream)}
                    //else if ('tcp-subsubsubsubnet:tcp-unnamed:tcp-subnet:tcp-subsubsubnet:http-tld:http-gaysex:http-dos:http-cf:udp-ipv6:tcp-ipv6portrange:nigga-subx8net:udp-anal:udp-nigger:udp-website:tcp-minecraft'.split(':').includes(cmd)) commands['misc-azN6tcbMgG'](args, stream, cmd)
                    stream.write(global.prefix)
                })
                stream.on('close', () => {
                    worker.terminate()
                }) 
            })
        })
    }).on('end', () => {
        logger.info(`Client Disconnected!`)
    })
}).listen(2222, '0.0.0.0', function() {
    logger.info('SSH Server is running on port ' + this.address().port)
})