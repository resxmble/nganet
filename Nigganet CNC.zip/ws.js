const express = require('express')
const http = require('http')
const WebSocket = require('ws')
const logger = require('./logger')

const app = express()
const server = http.createServer(app)
const wss = new WebSocket.Server({ server })

const clients = new Set()
let clientId = 0

wss.on('connection', ws => {
    clients.add(ws)
    ws.clientId = clientId
    clientId += 1
    logger.info(`Client connected with clientId #${ws.clientId}`)
    ws.on('close', () => {
        logger.info(`Client #${ws.clientId} disconnected`)
        clients.delete(ws)
    })
})

async function attack(time) {
    await new Promise(r => setTimeout(r, 2000))
    clients.forEach(ws => {
        if (ws.readyState !== WebSocket.OPEN) return
        ws.send(time)
    })
}

server.listen(6942, () => {
    logger.info('Websocket server is running')
})

module.exports = {
    attack,
    server
}